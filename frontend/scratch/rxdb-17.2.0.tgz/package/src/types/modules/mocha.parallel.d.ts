declare module 'mocha.parallel';
