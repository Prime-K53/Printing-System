# RxDB Error Messages

This file is generated automatically. Do not edit it manually.

## undefined

**Message**: `given name is no string or empty`

**Cause**: The database name must be a non-empty string.

**Fix**: Check the name used when creating the database.

---

## undefined

**Message**: `collection- and database-names must match the regex to be compatible with couchdb databases.
    See https://neighbourhood.ie/blog/2020/10/13/everything-you-need-to-know-about-couchdb-database-names/
    info: if your database-name specifies a folder, the name must contain the slash-char '/' or '\'`

**Cause**: The database name does not match the regex required for CouchDB compatibility.

**Fix**: Change the database name to match the regex: ^[a-z][_$a-zA-Z0-9\-]*$

---

## undefined

**Message**: `replication-direction must either be push or pull or both. But not none`

**Cause**: Replication must have at least one direction (push or pull) enabled.

**Fix**: Set push or pull to true or provide options for them.

**Docs**: https://rxdb.info/replication.html?console=errors&code=UT3

---

## undefined

**Message**: `given leveldown is no valid adapter`

---

## undefined

**Message**: `keyCompression is set to true in the schema but no key-compression handler is used in the storage`

**Cause**: Key compression is not supported by this RxStorage adapter or you forgot to add the key-compression plugin.

**Fix**: Disable key compression in the schema or add the proper plugin.

---

## undefined

**Message**: `schema contains encrypted fields but no encryption handler is used in the storage`

**Cause**: Encryption is not supported by this RxStorage adapter or you forgot to add the encryption plugin.

**Fix**: Disable encryption in the schema or add the proper plugin.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=UT6

---

## undefined

**Message**: `attachments.compression is enabled but no attachment-compression plugin is used`

**Cause**: Attachment compression is not supported by this RxStorage adapter or you forgot to add the attachment-compression plugin.

**Fix**: Disable attachment compression in the schema or add the proper plugin.

---

## undefined

**Message**: `crypto.subtle.digest is not available in your runtime. For expo/react-native you need to polyfill those, see https://github.com/pubkey/rxdb/blob/master/examples/react-native/initializeDb.js#L24 `

**Cause**: The Web Crypto API is not available in this environment.

**Fix**: Use a polyfill or an environment that supports the Web Crypto API, or provide a custom hash function.

**Docs**: https://rxdb.info/rx-database.html?console=errors&code=UT8#ignoreduplicate

---

## undefined

**Message**: `Given plugin is not RxDB plugin.`

**Cause**: The added plugin is not a valid RxDB plugin object.

**Fix**: Ensure you are adding a valid RxDB plugin object.

**Docs**: https://rxdb.info/plugins.html?console=errors&code=PL1

---

## undefined

**Message**: `A plugin with the same name was already added but it was not the exact same JavaScript object`

**Cause**: A plugin with the same name has already been added.

**Fix**: Check if you are adding the same plugin twice or if you have multiple versions of the same plugin.

**Docs**: https://rxdb.info/plugins.html?console=errors&code=PL3

---

## undefined

**Message**: `bulkWrite() cannot be called with an empty array`

**Cause**: bulkWrite was called with an empty array of documents.

**Fix**: Ensure the array passed to bulkWrite is not empty.

---

## undefined

**Message**: `RxQuery._execOverDatabase(): op not known`

**Cause**: Unknown RxQuery operation.

**Fix**: This is likely an internal error. Contact the maintainer.

---

## undefined

**Message**: `RxQuery.regex(): You cannot use .regex() on the primary field`

**Cause**: This is not supported by the query engine.

**Fix**: Use a different field or a primary key lookup.

**Docs**: https://rxdb.info/rx-query.html?console=errors&code=QU4

---

## undefined

**Message**: `RxQuery.sort(): does not work because key is not defined in the schema`

**Cause**: The field used for sorting is not defined in the schema.

**Fix**: Add the field to the schema or sort by a different field.

**Docs**: https://rxdb.info/rx-query.html?console=errors&code=QU5#sort

---

## undefined

**Message**: `RxQuery.limit(): cannot be called on .findOne()`

**Cause**: findOne queries cannot have a limit.

**Fix**: Remove the limit from the query or use find() instead.

**Docs**: https://rxdb.info/rx-query.html?console=errors&code=QU6

---

## undefined

**Message**: `throwIfMissing can only be used in findOne queries`

**Cause**: throwIfMissing was used on a find query.

**Fix**: Use findOne if you want to use throwIfMissing or remove the flag.

---

## undefined

**Message**: `result empty and throwIfMissing: true`

**Cause**: exec(true) or remove(true) was called on a findOne() query but the document was not found.

**Fix**: Ensure the document exists or do not use the throwIfMissing flag.

---

## undefined

**Message**: `RxQuery: no valid query params given`

**Cause**: The query object is not a valid Mango query or contains invalid keys.

**Fix**: Ensure the query object is a valid Mango query.

**Docs**: https://rxdb.info/rx-query.html?console=errors&code=QU11

---

## undefined

**Message**: `Given index is not in schema`

**Cause**: The index used in the query is not defined in the schema.

**Fix**: Add the index to the schema or use a different index.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=QU12#indexes

---

## undefined

**Message**: `A top level field of the query is not included in the schema`

**Cause**: A field used in the query is not defined in the schema.

**Fix**: Ensure all fields in the query are defined in the schema.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=QU13

---

## undefined

**Message**: `Running a count() query in slow mode is now allowed. Either run a count() query with a selector that fully matches an index or set allowSlowCount=true when calling the createRxDatabase`

**Cause**: A count query is running without an index, which is slow.

**Fix**: Add an index for the query or allow slow count queries.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=QU14#count

---

## undefined

**Message**: `For count queries it is not allowed to use skip or limit`

**Cause**: Count queries cannot have a limit or skip.

**Fix**: Remove limit and skip from the count query.

---

## undefined

**Message**: `$regex queries must be defined by a string, not an RegExp instance. This is because RegExp objects cannot be JSON stringified and also they are mutable which would be dangerous`

**Cause**: RegExp objects are not allowed in queries.

**Fix**: Use string based regex operators instead.

**Docs**: https://rxdb.info/rx-query.html?console=errors&code=QU16#regex

---

## undefined

**Message**: `Chained queries cannot be used on findByIds() RxQuery instances`

**Cause**: Query builder methods cannot be used with findByIds.

**Fix**: Use find() if you want to use the query builder.

---

## undefined

**Message**: `Malformed query result data. This likely happens because you create a OPFS-storage RxDatabase inside of a worker but did not set the usesRxDatabaseInWorker setting. https://rxdb.info/rx-storage-opfs.html?console=opfs#setting-usesrxdatabaseinworker-when-a-rxdatabase-is-also-used-inside-of-the-worker `

**Cause**: The result data for the query is undefined or malformed.

**Fix**: Check if you are using OPFS in a worker correctly.

**Docs**: https://rxdb.info/rx-storage-opfs.html?console=errors&code=QU18#setting-usesrxdatabaseinworker-when-a-rxdatabase-is-also-used-inside-of-the-worker

---

## undefined

**Message**: `Queries must not contain fields or properties with the value `undefined`: https://github.com/pubkey/rxdb/issues/6792#issuecomment-2624555824 `

**Cause**: A field in the query is undefined.

**Fix**: Ensure all fields in the query have valid values.

**Docs**: https://github.com/pubkey/rxdb/issues/6792?console=errors&code=QU19#issuecomment-2624555824

---

## undefined

**Message**: `path must be a string or object`

---

## undefined

**Message**: `Invalid argument`

---

## undefined

**Message**: `Invalid sort() argument. Must be a string, object, or array`

---

## undefined

**Message**: `Invalid argument. Expected instanceof mquery or plain object`

---

## undefined

**Message**: `method must be used after where() when called with these arguments`

---

## undefined

**Message**: `Can't mix sort syntaxes. Use either array or object | .sort([['field', 1], ['test', -1]]) | .sort({ field: 1, test: -1 })`

---

## undefined

**Message**: `Invalid sort value`

---

## undefined

**Message**: `Can't mix sort syntaxes. Use either array or object`

---

## undefined

**Message**: `RxDocument.prepare(): another instance on this adapter has a different password`

**Cause**: You tried to create a secondary instance on an adapter that is already used by another instance with a different password.

**Fix**: Ensure that all instances use the same password.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=DB1

---

## undefined

**Message**: `RxDatabase.addCollections(): collection-names cannot start with underscore _`

**Cause**: You tried to create a collection where the name starts with an underscore.

**Fix**: Change the collection name so it does not start with an underscore.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=DB2

---

## undefined

**Message**: `RxDatabase.addCollections(): collection already exists. use myDatabase[collectionName] to get it`

**Cause**: You tried to add a collection that already exists on this database instance.

**Fix**: Use the existing collection or use a different name.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=DB3

---

## undefined

**Message**: `RxDatabase.addCollections(): schema is missing`

**Cause**: You called addCollections() but did not provide a schema for the collection.

**Fix**: Provide a valid schema for the collection.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DB4

---

## undefined

**Message**: `RxDatabase.addCollections(): collection-name not allowed`

**Cause**: You used a collection name that contains invalid characters.

**Fix**: Use only allowed characters (a-z, A-Z, 0-9, -, _).

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=DB5

---

## undefined

**Message**: `RxDatabase.addCollections(): another instance created this collection with a different schema. Read thishttps://rxdb.info/rx-schema.html?console=qa#faq `

**Cause**: The schema hash does not match the schema stored in the internal database.

**Fix**: If you changed the schema, you must increment the version number. If not, check why the hash is different.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DB6#faq

---

## undefined

**Message**: `createRxDatabase(): A RxDatabase with the same name and adapter already exists.
Make sure to use this combination of storage+databaseName only once
If you have the duplicate database on purpose to simulate multi-tab behavior in unit tests, set "ignoreDuplicate: true".
As alternative you can set "closeDuplicates: true" like if this happens in your react projects with hot reload that reloads the code without reloading the process.`

**Cause**: You created multiple RxDatabase instances with the same name and adapter.

**Fix**: Ensure that you only create one instance of the database.

**Docs**: https://rxdb.info/rx-database.html?console=errors&code=DB8

---

## undefined

**Message**: `ignoreDuplicate is only allowed in dev-mode and must never be used in production`

**Cause**: You used the ignoreDuplicate option in a production environment.

**Fix**: Remove ignoreDuplicate: true or switch to dev-mode.

**Docs**: https://rxdb.info/rx-database.html?console=errors&code=DB9

---

## undefined

**Message**: `createRxDatabase(): Invalid db-name, folder-paths must not have an ending slash`

**Cause**: The database name or path has a trailing slash.

**Fix**: Remove the trailing slash from the name/path.

**Docs**: https://rxdb.info/rx-database.html?console=errors&code=DB11

---

## undefined

**Message**: `RxDatabase.addCollections(): could not write to internal store`

**Cause**: Writing to the internal storage failed.

**Fix**: Check your storage configuration and permissions.

**Docs**: https://rxdb.info/rx-storage.html?console=errors&code=DB12

---

## undefined

**Message**: `createRxDatabase(): Invalid db-name or collection name, name contains the dollar sign`

**Cause**: The name contains a dollar sign which is not allowed.

**Fix**: Remove the dollar sign from the name.

**Docs**: https://rxdb.info/rx-database.html?console=errors&code=DB13

---

## undefined

**Message**: `no custom reactivity factory added on database creation`

**Cause**: You tried to use reactivity but no factory was provided.

**Fix**: Add a reactivity factory (e.g. for React, Vue, Angular) or use a plugin that adds one.

**Docs**: https://rxdb.info/reactivity.html?console=errors&code=DB14

---

## undefined

**Message**: `RxDocument.insert() You cannot insert an existing document`

**Cause**: You tried to insert a document with a primary key that already exists.

**Fix**: Use upsert() if you want to overwrite.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=COL1#insert

---

## undefined

**Message**: `RxCollection.insert() fieldName ._id can only be used as primaryKey`

**Cause**: You have a field named "_id" but it is not defined as the primary key.

**Fix**: Rename the field or use it as the primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=COL2

---

## undefined

**Message**: `RxCollection.upsert() does not work without primary`

**Cause**: You called upsert() but the document data does not contain the primary key.

**Fix**: Ensure the primary key is present in the document data.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=COL3#upsert

---

## undefined

**Message**: `RxCollection.incrementalUpsert() does not work without primary`

**Cause**: You called incrementalUpsert() but the document data does not contain the primary key.

**Fix**: Ensure the primary key is present in the document data.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=COL4#incrementalupsert

---

## undefined

**Message**: `RxCollection.find() if you want to search by _id, use .findOne(_id)`

**Cause**: You called find() with a string argument, which was supported in older versions.

**Fix**: Use findOne(id) to find a single document by ID.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=COL5#find

---

## undefined

**Message**: `RxCollection.findOne() needs a queryObject or string. Notice that in RxDB, primary keys must be strings and cannot be numbers.`

**Cause**: You called findOne() with an invalid argument (likely a number or array).

**Fix**: Use a string ID or a mongo-style query object.

**Docs**: https://rxdb.info/rx-collection.html?console=errors&code=COL6#findone

---

## undefined

**Message**: `hook must be a function`

**Cause**: You provided a hook that is not a function.

**Fix**: Ensure the hook is a function.

**Docs**: https://rxdb.info/middleware.html?console=errors&code=COL7

---

## undefined

**Message**: `hooks-when not known`

**Cause**: You provided a hook with an invalid "when" parameter (must be "pre" or "post").

**Fix**: Use "pre" or "post" as the "when" parameter.

**Docs**: https://rxdb.info/middleware.html?console=errors&code=COL8

---

## undefined

**Message**: `RxCollection.addHook() hook-name not known`

**Cause**: You provided a hook name that is not known (e.g. insert, save, remove).

**Fix**: Use a valid hook name.

**Docs**: https://rxdb.info/middleware.html?console=errors&code=COL9

---

## undefined

**Message**: `RxCollection .postCreate-hooks cannot be async`

**Cause**: You defined a postCreate hook as async, which is not allowed.

**Fix**: Make the postCreate hook synchronous.

**Docs**: https://rxdb.info/middleware.html?console=errors&code=COL10

---

## undefined

**Message**: `migrationStrategies must be an object`

**Cause**: You provided migration strategies that are not an object.

**Fix**: Provide an object mapping versions to migration functions.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=COL11

---

## undefined

**Message**: `A migrationStrategy is missing or too much`

**Cause**: The number of migration strategies does not match the schema version difference.

**Fix**: Ensure you have a migration strategy for every version step.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=COL12

---

## undefined

**Message**: `migrationStrategy must be a function`

**Cause**: One of your migration strategies is not a function.

**Fix**: Ensure all migration strategies are functions.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=COL13

---

## undefined

**Message**: `given static method-name is not a string`

**Cause**: The name of a static method is not a string.

**Fix**: Provide a string as the method name.

**Docs**: https://rxdb.info/orm.html?console=errors&code=COL14

---

## undefined

**Message**: `static method-names cannot start with underscore _`

**Cause**: You tried to define a static method starting with an underscore.

**Fix**: Rename the method.

**Docs**: https://rxdb.info/orm.html?console=errors&code=COL15

---

## undefined

**Message**: `given static method is not a function`

**Cause**: You provided a static method that is not a function.

**Fix**: Ensure the static method is a function.

**Docs**: https://rxdb.info/orm.html?console=errors&code=COL16

---

## undefined

**Message**: `RxCollection.ORM: statics-name not allowed`

**Cause**: You used a reserved name for a static method.

**Fix**: Choose a different name for the static method.

**Docs**: https://rxdb.info/orm.html?console=errors&code=COL17

---

## undefined

**Message**: `collection-method not allowed because fieldname is in the schema`

**Cause**: You tried to define a collection method that conflicts with a schema field.

**Fix**: Rename the collection method or the schema field.

**Docs**: https://rxdb.info/orm.html?console=errors&code=COL18

---

## undefined

**Message**: `Storage write error`

**Cause**: The storage engine returned an error when writing data.

**Fix**: Check the error details.

**Docs**: https://rxdb.info/rx-storage.html?console=errors&code=COL20

---

## undefined

**Message**: `The RxCollection is closed or removed already, either from this JavaScript realm or from another, like a browser tab`

**Cause**: You tried to access a collection that has been closed or removed.

**Fix**: Ensure the collection is open before accessing it.

---

## undefined

**Message**: `WebMCP Agent attempted to delete a document that does not exist`

**Cause**: The explicitly requested ID for deletion could not be found in the database.

**Fix**: Ensure the agent queries for the document correctly before trying to delete it.

---

## undefined

**Message**: `Document update conflict. When changing a document you must work on the previous revision`

**Cause**: You tried to update a document but the revision you provided is not the latest one.

**Fix**: Fetch the latest document revision and apply your changes again.

**Docs**: https://rxdb.info/transactions-conflicts-revisions.html?console=errors&code=CONFLICT

---

## undefined

**Message**: `.bulkInsert() and .bulkUpsert() cannot be run with multiple documents that have the same primary key. Conflicting primary key(s) are in the error parameters (duplicateIds)`

**Cause**: You provided multiple documents with the same primary key in a bulk write.

**Fix**: Ensure all documents in a bulk write have unique primary keys.

---

## undefined

**Message**: `In the open-source version of RxDB, the amount of collections that can exist in parallel is limited to 16. If you already purchased the premium access, you can remove this limit: https://rxdb.info/rx-collection.html?console=limit#faq`

**Cause**: You have reached the limit of open collections for the free version.

**Fix**: Reduce the number of open collections or upgrade to premium.

**Docs**: https://rxdb.info/premium.html?console=errors&code=COL23

---

## undefined

**Message**: `inline _attachments must be an array of { id, type, data } objects; the map format is reserved for internal use only`

**Cause**: An object was passed as _attachments that is neither an array of attachment creators nor a fully-normalized internal map.

**Fix**: Pass attachments as an array: [{ id, type, data }]. This is the same format used by putAttachment().

**Docs**: https://rxdb.info/rx-attachment.html?console=errors&code=COL24

---

## undefined

**Message**: `RxDocument.get$ cannot get observable of in-array fields because order cannot be guessed`

**Cause**: You tried to observe an array item, which is not supported.

**Fix**: Observe the array field itself.

---

## undefined

**Message**: `cannot observe primary path`

**Cause**: You tried to observe the primary key, which is immutable.

**Fix**: Observe the document itself or use findOne().

---

## undefined

**Message**: `final fields cannot be observed`

**Cause**: You tried to observe a final field, which is immutable.

**Fix**: Observe the document itself.

---

## undefined

**Message**: `RxDocument.get$ cannot observe a non-existed field`

**Cause**: The field you tried to observe is not defined in the schema.

**Fix**: Check the field name and schema definition.

---

## undefined

**Message**: `RxDocument.populate() cannot populate a non-existed field`

**Cause**: The field you tried to populate is not defined in the schema.

**Fix**: Check the field name and schema definition.

**Docs**: https://rxdb.info/population.html?console=errors&code=DOC5

---

## undefined

**Message**: `RxDocument.populate() cannot populate because path has no ref`

**Cause**: The field you tried to populate does not have a "ref" property in the schema.

**Fix**: Add the "ref" property to the field schema.

**Docs**: https://rxdb.info/population.html?console=errors&code=DOC6

---

## undefined

**Message**: `RxDocument.populate() ref-collection not in database`

**Cause**: The collection referenced in the schema does not exist.

**Fix**: Create the referenced collection.

**Docs**: https://rxdb.info/population.html?console=errors&code=DOC7

---

## undefined

**Message**: `RxDocument.set(): primary-key cannot be modified`

**Cause**: You tried to modify the primary key of a document.

**Fix**: Primary keys are immutable. Create a new document with the new ID instead.

---

## undefined

**Message**: `final fields cannot be modified`

**Cause**: You tried to modify a field marked as final in the schema.

**Fix**: Final fields are immutable.

---

## undefined

**Message**: `RxDocument.set(): cannot set childpath when rootPath not selected`

**Cause**: You tried to set a nested field without having the root path in the document data.

**Fix**: Ensure the root path exists before setting nested fields.

---

## undefined

**Message**: `RxDocument.save(): can't save deleted document`

**Cause**: You tried to save a document that has already been deleted.

**Fix**: Do not save deleted documents. Insert them again if you want to recreate them.

---

## undefined

**Message**: `RxDocument.remove(): Document is already deleted`

**Cause**: You tried to remove a document that is already deleted.

**Fix**: Check if the document is deleted before removing it.

---

## undefined

**Message**: `RxDocument.close() does not exist`

**Cause**: You called close() on a RxDocument, which is not supported.

**Fix**: Documents do not need to be closed.

---

## undefined

**Message**: `query cannot be an array`

**Cause**: You provided an array as a query, which is not valid.

**Fix**: Provide a valid query object.

---

## undefined

**Message**: `Since version 8.0.0 RxDocument.set() can only be called on temporary RxDocuments`

**Cause**: You called set() on a non-temporary document.

**Fix**: Use update(), patch() or modify() to change document data.

**Docs**: https://rxdb.info/rx-document.html?console=errors&code=DOC16#update

---

## undefined

**Message**: `Since version 8.0.0 RxDocument.save() can only be called on non-temporary documents`

**Cause**: You called save() on a temporary document.

**Fix**: Use another method to save the document or ensure it is not temporary.

**Docs**: https://rxdb.info/rx-document.html?console=errors&code=DOC17#save

---

## undefined

**Message**: `Document property for composed primary key is missing`

**Cause**: A field required for the composite primary key is missing in the document data.

**Fix**: Ensure all fields of the composite primary key are set.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC18#composite-primary-key

---

## undefined

**Message**: `Value of primary key(s) cannot be changed`

**Cause**: You tried to modify the primary key of a document.

**Fix**: Primary keys are immutable. Create a new document with the new ID instead.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC19#primary-key

---

## undefined

**Message**: `PrimaryKey missing`

**Cause**: The document data is missing a primary key.

**Fix**: Ensure the document has a primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC20#primary-key

---

## undefined

**Message**: `PrimaryKey must be equal to PrimaryKey.trim(). It cannot start or end with a whitespace`

**Cause**: The primary key contains leading or trailing whitespace.

**Fix**: Trim the primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC21#primary-key

---

## undefined

**Message**: `PrimaryKey must not contain a linebreak`

**Cause**: The primary key contains newline characters.

**Fix**: Remove newline characters from the primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC22#primary-key

---

## undefined

**Message**: `PrimaryKey must not contain a double-quote ["]`

**Cause**: The primary key contains double quotes.

**Fix**: Remove double quotes from the primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC23#primary-key

---

## undefined

**Message**: `Given document data could not be structured cloned. This happens if you pass non-plain-json data into it, like a Date() object or a Function. In vue.js this happens if you use ref() on the document data which transforms it into a Proxy object.`

**Cause**: The document data contains objects that cannot be structured-cloned (e.g. Date, RegExp).

**Fix**: Use only JSON-serializable data. Store dates as strings.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=DOC24

---

## undefined

**Message**: `migrate() Migration has already run`

**Cause**: You tried to run the migration manually but it has already been finished.

**Fix**: Check if the migration is already done.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=DM1

---

## undefined

**Message**: `migration of document failed final document does not match final schema`

**Cause**: The migration strategy produced a document that does not match the new schema.

**Fix**: Check your migration strategy and the new schema.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=DM2

---

## undefined

**Message**: `migration already running`

**Cause**: You started the migration while another migration is already running.

**Fix**: Await the running migration.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=DM3

---

## undefined

**Message**: `Migration errored`

**Cause**: An error occurred during migration.

**Fix**: Check the error details.

**Docs**: https://rxdb.info/migration-schema.html?console=errors&code=DM4

---

## undefined

**Message**: `Cannot open database state with newer RxDB version. You have to migrate your database state first. See https://rxdb.info/migration-storage.html?console=storage `

**Cause**: The database was created with an older RxDB version and needs migration.

**Fix**: Run the storage migration.

**Docs**: https://rxdb.info/migration-storage.html?console=errors&code=DM5

---

## undefined

**Message**: `to use attachments, please define this in your schema`

**Cause**: You tried to use attachments but they are not enabled in the schema.

**Fix**: Enable attachments in the schema.

**Docs**: https://rxdb.info/rx-attachment.html?console=errors&code=AT1

---

## undefined

**Message**: `inline attachment must have id and type (strings) and data (Blob)`

**Cause**: An inline attachment object is missing a required field or data is not a Blob instance.

**Fix**: Ensure each inline attachment has { id: string, type: string, data: Blob }.

**Docs**: https://rxdb.info/rx-attachment.html?console=errors&code=AT2

---

## undefined

**Message**: `duplicate attachment id`

**Cause**: The same attachment id appears multiple times in the inline attachments array.

**Fix**: Ensure each attachment id is unique in the array.

**Docs**: https://rxdb.info/rx-attachment.html?console=errors&code=AT3

---

## undefined

**Message**: `_attachments missing on document`

**Cause**: A document is missing the _attachments property during an attachments write operation.

**Fix**: Ensure documents have the _attachments property set.

**Docs**: https://rxdb.info/rx-attachment.html?console=errors&code=AT4

---

## undefined

**Message**: `password is not valid`

**Cause**: The password provided is invalid (must be a string).

**Fix**: Provide a valid string password.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=EN1

---

## undefined

**Message**: `validatePassword: min-length of password not complied`

**Cause**: The password is too short.

**Fix**: Use a longer password (min 12 chars).

**Docs**: https://rxdb.info/encryption.html?console=errors&code=EN2

---

## undefined

**Message**: `Schema contains encrypted properties but no password is given`

**Cause**: Encryption enabled in schema but no password provided.

**Fix**: Provide a password.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=EN3

---

## undefined

**Message**: `Password not valid`

**Cause**: The password provided is invalid.

**Fix**: Check the password.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=EN4

---

## undefined

**Message**: `Storage wrapper received a string instead of an array from the storage. This happens when a storage like OPFS is used inside of a worker and the usesRxDatabaseInWorker option is not set.`

**Cause**: Some RxStorage implementations (like OPFS) return JSON strings instead of arrays for performance. When you wrap such a storage with encryption (or other plugins) inside of a worker, the wrapper receives the raw string and cannot process it.

**Fix**: Set usesRxDatabaseInWorker: true in your storage options. For example: getRxStorageOPFS({ usesRxDatabaseInWorker: true }).

**Docs**: https://rxdb.info/encryption.html?console=errors&code=EN5

---

## undefined

**Message**: `You must create the collections before you can import their data`

**Cause**: Importing data into a non-existent collection.

**Fix**: Create the collection before importing.

**Docs**: https://rxdb.info/backup.html?console=errors&code=JD1

---

## undefined

**Message**: `RxCollection.importJSON(): the imported json relies on a different schema`

**Cause**: The imported data schema does not match the collection schema.

**Fix**: Ensure schemas match.

**Docs**: https://rxdb.info/backup.html?console=errors&code=JD2

---

## undefined

**Message**: `RxCollection.importJSON(): json.passwordHash does not match the own`

**Cause**: Password mismatch in import.

**Fix**: Use the same password.

**Docs**: https://rxdb.info/backup.html?console=errors&code=JD3

---

## undefined

**Message**: `RxDocument.allAttachments$ can't use attachments on local documents`

**Cause**: You tried to use attachments on a local document, which is not supported.

**Fix**: Do not use attachments with local documents.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD1

---

## undefined

**Message**: `RxDocument.get(): objPath must be a string`

**Cause**: The object path provided to get() is not a string.

**Fix**: Provide a valid string path.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD2

---

## undefined

**Message**: `RxDocument.get$ cannot get observable of in-array fields because order cannot be guessed`

**Cause**: You tried to observe an array item in a local document.

**Fix**: Observe the whole array instead.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD3

---

## undefined

**Message**: `cannot observe primary path`

**Cause**: You tried to observe the primary path of a local document.

**Fix**: Observe the document data instead.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD4

---

## undefined

**Message**: `RxDocument.set() id cannot be modified`

**Cause**: You tried to modify the ID of a local document.

**Fix**: IDs are immutable. Create a new document if needed.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD5

---

## undefined

**Message**: `LocalDocument: Function is not usable on local documents`

**Cause**: You called a function that is not supported on local documents.

**Fix**: Check the documentation for supported methods.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD6

---

## undefined

**Message**: `Local document already exists`

**Cause**: You tried to create a local document that already exists.

**Fix**: Use upsert() or update the existing document.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD7

---

## undefined

**Message**: `localDocuments not activated. Set localDocuments=true on creation, when you want to store local documents on the RxDatabase or RxCollection.`

**Cause**: You tried to use local documents but they are not enabled.

**Fix**: Enable local documents when creating the database or collection.

**Docs**: https://rxdb.info/rx-local-document.html?console=errors&code=LD8

---

## undefined

**Message**: `Replication: already added`

**Cause**: You started a replication that is already running.

**Fix**: Check if the replication is already running before starting it.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC1

---

## undefined

**Message**: `replicateCouchDB() query must be from the same RxCollection`

**Cause**: You used a query from a different collection for replication.

**Fix**: Use a query from the same collection.

**Docs**: https://rxdb.info/replication-couchdb.html?console=errors&code=RC2

---

## undefined

**Message**: `RxCouchDBReplicationState.awaitInitialReplication() cannot await initial replication when live: true`

**Cause**: You tried to await initial replication on a live replication.

**Fix**: Set live: false if you want to await initial replication.

**Docs**: https://rxdb.info/replication-couchdb.html?console=errors&code=RC4

---

## undefined

**Message**: `RxCouchDBReplicationState.awaitInitialReplication() cannot await initial replication if multiInstance because the replication might run on another instance`

**Cause**: You tried to await initial replication in a multi-instance environment.

**Fix**: Await initial replication only in single-instance mode.

**Docs**: https://rxdb.info/replication-couchdb.html?console=errors&code=RC5

---

## undefined

**Message**: `syncFirestore() serverTimestampField MUST NOT be part of the collections schema and MUST NOT be nested.`

**Cause**: The serverTimestampField is defined in the schema or is nested.

**Fix**: Remove the serverTimestampField from the schema and ensure it is at the top level.

**Docs**: https://rxdb.info/replication-firestore.html?console=errors&code=RC6

---

## undefined

**Message**: `SimplePeer requires to have process.nextTick() polyfilled, see https://rxdb.info/replication-webrtc.html?console=webrtc `

**Cause**: process.nextTick is missing in the runtime environment.

**Fix**: Polyfill process.nextTick.

**Docs**: https://rxdb.info/replication-webrtc.html?console=errors&code=RC7

---

## undefined

**Message**: `RxReplication pull handler threw an error - see .errors for more details`

**Cause**: The pull handler of the replication threw an error.

**Fix**: Check the error details in the .errors observable.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_PULL

---

## undefined

**Message**: `RxReplication pull stream$ threw an error - see .errors for more details`

**Cause**: The pull stream of the replication threw an error.

**Fix**: Check the error details in the .errors observable.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_STREAM

---

## undefined

**Message**: `RxReplication push handler threw an error - see .errors for more details`

**Cause**: The push handler of the replication threw an error.

**Fix**: Check the error details in the .errors observable.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_PUSH

---

## undefined

**Message**: `RxReplication push handler did not return an array with the conflicts`

**Cause**: The push handler returned a non-array value.

**Fix**: Ensure the push handler returns an array of conflicting documents.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_PUSH_NO_AR

---

## undefined

**Message**: `RxReplication WebRTC Peer has error`

**Cause**: A WebRTC peer connection error occurred.

**Fix**: Check the network connection and WebRTC configuration.

**Docs**: https://rxdb.info/replication-webrtc.html?console=errors&code=RC_WEBRTC_PEER

---

## undefined

**Message**: `replicateCouchDB() url must end with a slash like 'https://example.com/mydatabase/'`

**Cause**: The CouchDB URL is missing a trailing slash.

**Fix**: Add a trailing slash to the URL.

**Docs**: https://rxdb.info/replication-couchdb.html?console=errors&code=RC_COUCHDB_1

---

## undefined

**Message**: `replicateCouchDB() did not get valid result with rows.`

**Cause**: The CouchDB endpoint returned an invalid response.

**Fix**: Check the CouchDB server and the URL.

**Docs**: https://rxdb.info/replication-couchdb.html?console=errors&code=RC_COUCHDB_2

---

## undefined

**Message**: `Outdated client, update required. Replication was canceled`

**Cause**: The client version is too old for the server.

**Fix**: Update the client application.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_OUTDATED

---

## undefined

**Message**: `Unauthorized client, update the replicationState.headers to set correct auth data`

**Cause**: The client is not authorized to replicate.

**Fix**: Update authentication headers.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_UNAUTHORIZED

---

## undefined

**Message**: `Client behaves wrong so the replication was canceled. Mostly happens if the client tries to write data that it is not allowed to`

**Cause**: The server rejected the replication request.

**Fix**: Check server permissions and logs.

**Docs**: https://rxdb.info/replication.html?console=errors&code=RC_FORBIDDEN

---

## undefined

**Message**: `fieldnames do not match the regex`

**Cause**: A field name in the schema contains invalid characters.

**Fix**: Use only allowed characters (a-z, A-Z, 0-9, _, -).

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC1

---

## undefined

**Message**: `SchemaCheck: name 'item' reserved for array-fields`

**Cause**: You used "item" as a field name, but it is reserved.

**Fix**: Rename the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC2

---

## undefined

**Message**: `SchemaCheck: fieldname has a ref-array but items-type is not string`

**Cause**: You defined a reference array but the items are not of type string.

**Fix**: Set the items type to string.

**Docs**: https://rxdb.info/population.html?console=errors&code=SC3

---

## undefined

**Message**: `SchemaCheck: fieldname has a ref but is not type string, [string,null] or array<string>`

**Cause**: You defined a reference field but the type is not string or array of strings.

**Fix**: Set the type to string or array of strings.

**Docs**: https://rxdb.info/population.html?console=errors&code=SC4

---

## undefined

**Message**: `SchemaCheck: primary can only be defined at top-level`

**Cause**: You defined the primary key in a nested object.

**Fix**: Move the primary key definition to the top level.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC6#primary-key

---

## undefined

**Message**: `SchemaCheck: default-values can only be defined at top-level`

**Cause**: You defined a default value in a nested object.

**Fix**: Move default values to the top level.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC7

---

## undefined

**Message**: `SchemaCheck: first level-fields cannot start with underscore _`

**Cause**: A top-level field name starts with an underscore.

**Fix**: Rename the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC8

---

## undefined

**Message**: `SchemaCheck: schema defines ._rev, this will be done automatically`

**Cause**: You defined _rev in your schema.

**Fix**: Remove _rev from the schema.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC10

---

## undefined

**Message**: `SchemaCheck: schema needs a number >=0 as version`

**Cause**: The version field is missing or invalid.

**Fix**: Set a valid version number (>=0).

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC11#version

---

## undefined

**Message**: `SchemaCheck: primary is always index, do not declare it as index`

**Cause**: You declared the primary key as an index, which is redundant.

**Fix**: Remove index: true from the primary key field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC13

---

## undefined

**Message**: `SchemaCheck: primary is always unique, do not declare it as index`

**Cause**: You declared the primary key as unique, which is redundant.

**Fix**: Remove unique: true from the primary key field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC14

---

## undefined

**Message**: `SchemaCheck: primary cannot be encrypted`

**Cause**: You tried to encrypt the primary key.

**Fix**: Primary keys cannot be encrypted.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=SC15

---

## undefined

**Message**: `SchemaCheck: primary must have type: string`

**Cause**: The primary key field has a type other than string.

**Fix**: Set the primary key type to string.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC16#primary-key

---

## undefined

**Message**: `SchemaCheck: top-level fieldname is not allowed. See https://rxdb.info/rx-schema.html?console=toplevel#non-allowed-properties `

**Cause**: You used a reserved name for a top-level field.

**Fix**: Rename the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC17

---

## undefined

**Message**: `SchemaCheck: indexes must be an array`

**Cause**: The indexes property is not an array.

**Fix**: Set indexes to an array of strings or arrays.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC18#indexes

---

## undefined

**Message**: `SchemaCheck: indexes must contain strings or arrays of strings`

**Cause**: An index definition is invalid.

**Fix**: Ensure indexes are strings or arrays of strings.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC19#indexes

---

## undefined

**Message**: `SchemaCheck: indexes.array must contain strings`

**Cause**: A compound index contains non-string values.

**Fix**: Ensure compound indexes contain only strings.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC20#indexes

---

## undefined

**Message**: `SchemaCheck: given index is not defined in schema`

**Cause**: You defined an index for a field that does not exist.

**Fix**: Check the field name in the index.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC21#indexes

---

## undefined

**Message**: `SchemaCheck: given indexKey is not type:string`

**Cause**: You defined an index on a non-string field.

**Fix**: Indexes are only supported on string fields (mostly).

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC22#indexes

---

## undefined

**Message**: `SchemaCheck: fieldname is not allowed`

**Cause**: You used a field name that is not allowed (e.g. starts with $ or _).

**Fix**: Rename the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC23

---

## undefined

**Message**: `SchemaCheck: required fields must be set via array. See https://spacetelescope.github.io/understanding-json-schema/reference/object.html#required`

**Cause**: The required fields are not defined as an array of strings.

**Fix**: Set required to an array of strings.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC24

---

## undefined

**Message**: `SchemaCheck: compoundIndexes needs to be specified in the indexes field`

**Cause**: Compound indexes are not defined correctly.

**Fix**: Define compound indexes in the indexes array.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC25#indexes

---

## undefined

**Message**: `SchemaCheck: indexes needs to be specified at collection schema level`

**Cause**: Indexes are defined at the wrong level (e.g. inside properties).

**Fix**: Move indexes to the top level of the schema.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC26#indexes

---

## undefined

**Message**: `SchemaCheck: encrypted fields is not defined in the schema`

**Cause**: You tried to use encryption but encrypted fields are not defined.

**Fix**: Define encrypted fields in the schema.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=SC28

---

## undefined

**Message**: `SchemaCheck: missing object key 'properties'`

**Cause**: The schema is missing the "properties" field.

**Fix**: Add the "properties" field to the schema.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC29

---

## undefined

**Message**: `SchemaCheck: primaryKey is required`

**Cause**: The schema is missing a primary key.

**Fix**: Define a primary key in the schema.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC30#primary-key

---

## undefined

**Message**: `SchemaCheck: primary field must have the type string/number/integer`

**Cause**: The primary key field has an invalid type.

**Fix**: Set the primary key type to string, number, or integer.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC32#primary-key

---

## undefined

**Message**: `SchemaCheck: used primary key is not a property in the schema`

**Cause**: The primary key field is not defined in the properties.

**Fix**: Add the primary key field to the properties.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC33#primary-key

---

## undefined

**Message**: `Fields of type string that are used in an index, must have set the maxLength attribute in the schema`

**Cause**: A string field used in an index is missing the maxLength attribute.

**Fix**: Set maxLength for the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC34#indexes

---

## undefined

**Message**: `Fields of type number/integer that are used in an index, must have set the multipleOf attribute in the schema`

**Cause**: A number field used in an index is missing the multipleOf attribute.

**Fix**: Set multipleOf for the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC35#indexes

---

## undefined

**Message**: `A field of this type cannot be used as index`

**Cause**: You tried to index a field type that cannot be indexed (e.g. object, array).

**Fix**: Remove the index or change the field type.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC36#indexes

---

## undefined

**Message**: `Fields of type number that are used in an index, must have set the minimum and maximum attribute in the schema`

**Cause**: A number field used in an index is missing minimum/maximum attributes.

**Fix**: Set minimum and maximum for the field.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC37#indexes

---

## undefined

**Message**: `Fields of type boolean that are used in an index, must be required in the schema`

**Cause**: A boolean field used in an index is not marked as required.

**Fix**: Mark the field as required.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC38#indexes

---

## undefined

**Message**: `The primary key must have the maxLength attribute set. Ensure you use the dev-mode plugin when developing with RxDB.`

**Cause**: The primary key field is missing the maxLength attribute.

**Fix**: Set maxLength for the primary key.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC39#primary-key

---

## undefined

**Message**: `$ref fields in the schema are not allowed. RxDB cannot resolve related schemas because it would have a negative performance impact.It would have to run http requests on runtime. $ref fields should be resolved during build time.`

**Cause**: You used $ref in the schema, which is not supported at runtime.

**Fix**: Resolve $ref fields during build time.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC40

---

## undefined

**Message**: `minimum, maximum and maxLength values for indexes must be real numbers, not Infinity or -Infinity`

**Cause**: You used Infinity for min/max/maxLength.

**Fix**: Use real numbers.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC41#indexes

---

## undefined

**Message**: `Primary key and also indexed fields which are strings, must have a maxLength that is <= 2048. Notice that having a big maxLength can negatively affect the performance. Only set it as big as it has to be.`

**Cause**: The maxLength is too large (> 2048).

**Fix**: Reduce the maxLength.

**Docs**: https://rxdb.info/rx-schema.html?console=errors&code=SC42#indexes

---

## undefined

**Message**: `Encrypted fields must not be nested inside other encrypted fields. When a parent path is encrypted, the whole object at that path is encrypted so specifying child paths is not allowed.`

**Cause**: An encrypted field is a child of another encrypted field.

**Fix**: Remove the child path from the encrypted array. Encrypting the parent path already encrypts all of its children.

**Docs**: https://rxdb.info/encryption.html?console=errors&code=SC43

---

## undefined

**Message**: `When dev-mode is enabled, your storage must use one of the schema validators at the top level. This is because most problems people have with RxDB is because they store data that is not valid to the schema which causes strange bugs and problems.`

**Cause**: The storage Adapter you use does not support schema validation.

**Fix**:  Wrap your storage with a validator like wrappedValidateAjvStorage()

**Docs**: https://rxdb.info/rx-storage.html?console=errors&code=DVM1

---

## undefined

**Message**: `Sub-schema not found, does the schemaPath exists in your schema?`

**Cause**: You tried to validate a sub-path that does not exist in the schema.

**Fix**: Check the schema path.

**Docs**: https://rxdb.info/schema-validation.html?console=errors&code=VD1

---

## undefined

**Message**: `object does not match schema`

**Cause**: RxCollection.insert()

**Fix**: Do not store data that does not match the collections schema

**Docs**: https://rxdb.info/schema-validation.html?console=errors&code=VD2

---

## undefined

**Message**: `You cannot create collections after calling RxDatabase.server()`

**Cause**: You tried to add a collection after starting the server.

**Fix**: Add all collections before starting the server.

**Docs**: https://rxdb.info/server.html?console=errors&code=S1

---

## undefined

**Message**: `GraphQL replication: cannot find sub schema by key`

**Cause**: The GraphQL schema is missing a definition for a key.

**Fix**: Check the GraphQL schema.

**Docs**: https://rxdb.info/replication-graphql.html?console=errors&code=GQL1

---

## undefined

**Message**: `GraphQL replication: pull returns more documents then batchSize`

**Cause**: The GraphQL endpoint returned more documents than requested.

**Fix**: Check the GraphQL resolver.

**Docs**: https://rxdb.info/replication-graphql.html?console=errors&code=GQL3

---

## undefined

**Message**: `CRDT operations cannot be used because the crdt options are not set in the schema.`

**Cause**: You tried to use CRDT features without enabling them in the schema.

**Fix**: Add crdt: { field: ... } to the schema.

**Docs**: https://rxdb.info/crdt.html?console=errors&code=CRDT1

---

## undefined

**Message**: `RxDocument.incrementalModify() cannot be used when CRDTs are activated.`

**Cause**: CRDTs replace the need for incrementalModify.

**Fix**: Use CRDT operations instead.

**Docs**: https://rxdb.info/crdt.html?console=errors&code=CRDT2

---

## undefined

**Message**: `To use CRDTs you MUST NOT set a conflictHandler because the default CRDT conflict handler must be used`

**Cause**: You defined a custom conflict handler with CRDTs.

**Fix**: Remove the custom conflict handler.

**Docs**: https://rxdb.info/crdt.html?console=errors&code=CRDT3

---

## undefined

**Message**: `RxDocument.modify() cannot be used when CRDTs are activated.`

**Cause**: modify() takes an arbitrary function that cannot be converted to a CRDT operation.

**Fix**: Use updateCRDT() instead of modify().

**Docs**: https://rxdb.info/crdt.html?console=errors&code=CRDT4

---

## undefined

**Message**: `non-required index fields are not possible with the dexie.js RxStorage: https://github.com/pubkey/rxdb/pull/6643#issuecomment-2505310082`

**Cause**: Dexie only supports indexes on required fields.

**Fix**: Make the indexed field required.

**Docs**: https://rxdb.info/rx-storage-dexie.html?console=errors&code=DXE1

---

## undefined

**Message**: `The trial version of the SQLite storage does not support attachments.`

**Cause**: You tried to use attachments with the trial SQLite storage.

**Fix**: Upgrade to the full version.

**Docs**: https://rxdb.info/rx-storage-sqlite.html?console=errors&code=SQL1

---

## undefined

**Message**: `The trial version of the SQLite storage is limited to contain 300 documents`

**Cause**: You reached the document limit of the trial version.

**Fix**: Upgrade to the full version.

**Docs**: https://rxdb.info/rx-storage-sqlite.html?console=errors&code=SQL2

---

## undefined

**Message**: `The trial version of the SQLite storage is limited to running 500 operations`

**Cause**: You reached the operation limit of the trial version.

**Fix**: Upgrade to the full version.

**Docs**: https://rxdb.info/rx-storage-sqlite.html?console=errors&code=SQL3

---

## undefined

**Message**: `Cannot communicate with a remote that was build on a different RxDB version. Did you forget to rebuild your workers when updating RxDB?`

**Cause**: The RxDB version of the remote does not match the local version.

**Fix**: Ensure both sides use the same RxDB version.

**Docs**: https://rxdb.info/rx-storage-remote.html?console=errors&code=RM1

---

## undefined

**Message**: `If _id is used as primaryKey, all documents in the MongoDB instance must have a string-value as _id, not an ObjectId or number`

**Cause**: Found a document in MongoDB where _id is not a string.

**Fix**: Ensure all documents in MongoDB have string IDs.

**Docs**: https://rxdb.info/replication-mongodb.html?console=errors&code=MG1

---

## undefined

**Message**: `You must provide a valid RxDatabase to the RxDatabaseProvider`

**Cause**: The database provided to the provider is invalid.

**Fix**: Ensure you pass a valid RxDatabase instance.

**Docs**: https://rxdb.info/react.html?console=errors&code=R1

---

## undefined

**Message**: `Could not find database in context, please ensure the component is wrapped in a <RxDatabaseProvider>`

**Cause**: You tried to use the database hook outside of a provider.

**Fix**: Wrap your component in <RxDatabaseProvider>.

**Docs**: https://rxdb.info/react.html?console=errors&code=R2

---

## undefined

**Message**: `The provided value for the collection parameter is not a valid RxCollection`

**Cause**: The collection passed to the hook is invalid.

**Fix**: Ensure you pass a valid RxCollection instance.

**Docs**: https://rxdb.info/react.html?console=errors&code=R3

---

## undefined

**Message**: `Google Drive: folderPath must not be the root folder or undefined`

**Cause**: You provided "/" or "root" or "" as folderPath.

**Fix**: Use a specific subfolder to ensure RxDB data does not mess up the users drive files.

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR1

---

## undefined

**Message**: `Google Drive: Folder already exists but is not a folder`

**Cause**: A file with the same name already exists, but is not a folder

**Fix**: Rename the file or the folder you are trying to create.

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR3

---

## undefined

**Message**: `Google Drive: folder has content but is not a rxdb sync target`

**Cause**: You selected a folder that is not empty but is not a rxdb sync target.

**Fix**: Provide empty folder or use a different folder that is not used for anything else.

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR9

---

## undefined

**Message**: `Google Drive: could not close transaction`

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR11

---

## undefined

**Message**: `Max batch size exxeeded for google drive sync`

**Fix**: Reduce the batchSize to be lower

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR18

---

## undefined

**Message**: `WAL file write conflict`

**Cause**: Someone else has written to the wal file in between our transaction. This should not happen.

**Fix**: Try to reproduce the error in a unit test and make a PR with a test case.

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR19

---

## undefined

**Message**: `Document file update conflict`

**Cause**: Another client modified the document file during the transaction. This indicates a transaction timeout overlap.

**Fix**: Increase the transactionTimeout or investigate why two clients are writing to the same document concurrently.

**Docs**: https://rxdb.info/replication-google-drive.html?console=errors&code=GDR20

---

## undefined

**Message**: `Microsoft OneDrive: folderPath must not be the root folder or undefined`

**Cause**: You provided "/" or "root" or "" as folderPath.

**Fix**: Use a specific subfolder to ensure RxDB data does not mess up the users drive files.

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR1

---

## undefined

**Message**: `Microsoft OneDrive: Folder already exists but is not a folder`

**Cause**: A file with the same name already exists, but is not a folder

**Fix**: Rename the file or the folder you are trying to create.

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR3

---

## undefined

**Message**: `Microsoft OneDrive: folder has content but is not a rxdb sync target`

**Cause**: You selected a folder that is not empty but is not a rxdb sync target.

**Fix**: Provide empty folder or use a different folder that is not used for anything else.

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR9

---

## undefined

**Message**: `Microsoft OneDrive: could not close transaction`

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR11

---

## undefined

**Message**: `Max batch size exceeded for Microsoft OneDrive sync`

**Fix**: Reduce the batchSize to be lower

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR18

---

## undefined

**Message**: `WAL file write conflict`

**Cause**: Someone else has written to the wal file in between our transaction. This should not happen.

**Fix**: Try to reproduce the error in a unit test and make a PR with a test case.

**Docs**: https://rxdb.info/replication-microsoft-onedrive.html?console=errors&code=ODR19

---

## undefined

**Message**: `A fetch-request failed`

**Cause**: A call with the javascript fetch() function failed

**Fix**: Check the network connection and the server logs.

---

## undefined

**Message**: `Field not in schema`

**Cause**: The given field is not defined in the RxJsonSchema.

**Fix**: Make sure the field name is spelled correctly and exists in the schema.

---

## undefined

**Message**: `Unknown index type`

**Cause**: The schema field type is not supported for indexing.

**Fix**: Use a supported type (string, boolean, number, integer) for the indexed field.

---

## undefined

**Message**: `ChangeEventBuffer out of bounds`

**Cause**: The requested pointer is out of the change event buffer bounds.

**Fix**: This means something in RxDB itself behaves wrong because any access to the api should not make an out of bounds request.

---

## undefined

**Message**: `This should never happen`

**Cause**: Should never be thrown. This error code is used for internal things like null-checks etc.

**Fix**: If this throws, you likely found a bug and should make a PR with a test case to the RxDB repo, so we can reproduce it.

**Docs**: https://rxdb.info/contribution.html

---

